{

    let canvas;
    let arrayColores = ["#7E57C2", "#5C6BC0", "#42A5F5", "#26A69A", "#66BB6A", "#FF7043", "#8D6E63", "#78909C"];

    function init(){

        canvas = Array.from(document.getElementsByTagName("canvas"));

        
        canvas.forEach(element => { 
            element.addEventListener(element.getAttribute("id"), ()=>{
                let aleatorio = Math.floor(Math.random() * (arrayColores.length - 0)) + 0;
                pintaCanvas(element,aleatorio);
            });
            pintaCanvas(element);
        });

    }

    let pintaCanvas = function(canvas,aleatorio){

        if (canvas.getContext) {
            let ctx = canvas.getContext('2d',{alpha:false});
            if (arguments.length === 1){
                ctx.fillStyle = "#EC407A";
            }else{
                ctx.fillStyle = arrayColores[aleatorio];
            }

            ctx.fillRect(0, 0, 500, 500);
            //'Lato', sans-serif
            ctx.font = "bold 1.1rem Lato";
            ctx.fillStyle = "#fff";
            ctx.fillText(canvas.getAttribute("id"), 50, 40);
        }
        

    }

    window.addEventListener("load", init);

}